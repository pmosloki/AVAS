uint8_t data[]={1,2};
uint8_t size =2;
 void aud_gen(int*,int);




void main()
{
    aud_gen(&data,size);

}



void aud_gen(uint8_t * data,uint8_t size)
{
    uint8_t i;
    for(i=0;i< data;i++)
    {
        (uint8_t)(((data[i] + 0x80)>> 8)+128);

    }

}
